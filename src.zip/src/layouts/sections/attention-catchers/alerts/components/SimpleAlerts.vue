<script setup>
//Vue Material Kit 2 components
import MaterialAlert from "@/components/MaterialAlert.vue";
</script>
<template>
  <div class="container py-5">
    <div class="row">
      <MaterialAlert color="success" fontWeight="bold"
        >A simple success alert—check it out!</MaterialAlert
      >
      <MaterialAlert color="primary" fontWeight="bold"
        >A simple primary alert—check it out!</MaterialAlert
      >
      <MaterialAlert color="secondary" fontWeight="bold"
        >A simple secondary alert—check it out!</MaterialAlert
      >
      <MaterialAlert color="danger" fontWeight="bold"
        >A simple danger alert—check it out!</MaterialAlert
      >
      <MaterialAlert color="warning" fontWeight="bold"
        >A simple warning alert—check it out!</MaterialAlert
      >
      <MaterialAlert color="info" fontWeight="bold"
        >A simple info alert—check it out!</MaterialAlert
      >
      <MaterialAlert color="light" fontWeight="bold"
        >A simple light alert—check it out!</MaterialAlert
      >
      <MaterialAlert color="dark" fontWeight="bold"
        >A simple dark alert—check it out!</MaterialAlert
      >
    </div>
  </div>
</template>
