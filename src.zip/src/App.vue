<script setup>
/*
=========================================================
* Youtube Downloader - v1.0.0
=========================================================
*/
import { RouterView } from "vue-router";
</script>

<template>
  <router-view />
</template>
